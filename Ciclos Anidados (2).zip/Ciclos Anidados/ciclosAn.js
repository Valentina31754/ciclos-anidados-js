// numeros de loteria
//for

// var series = parseInt(prompt("Dijite un nuemro de serie "));
 //var numerosDeSerie = parseInt(prompt("Dijite un numero de cada serie"));

 //ciclo externo
/*
 for(var x=1 ;x<=series; x++){
    document.write("serie#"+x+"<br>");
    for(var y =1;y<=numerosDeSerie;y++){
        document.write("#"+y+"<br>");

    }

 }

 //ciclo while
 var  contador1=1;
 while(contador1<=series){
    document.write("serie#"+contador+"<br>");
    var contador2=1;
    while(contador2<=numerosDeSerie){
        document.write("#"+contador2+"<br>");
        contador2++
    }

    contador++

 }

 //punto 8

 var altura=parseInt(prompt("dijite el numero"))
 var x=1;
 while(x<=altura){
    var y=1;
    while(x>=y){
        document.write("*")
        y++
    }
    document.write("<br>")
    x++

 
 var altura=parseInt(prompt("dijite el numero"));

 for(var x=1;x<=altura;x++){
    for(var y=1;x>=y;y++){
        document.write("*");

    }
    document.write("<br>")
 }
 


//punto 9
 var altura=parseInt(prompt("dijite el numero"));
 var x=1;
 while(x<=altura){
    var y=altura;
    while(y>=x){
        document.write("*");
        y--;
    }
    document.write("<br>");
    x++;

 }

var altura = parseInt(prompt("Digite un número"));
for(x = 1; x <= altura; x++){
    for( y = altura; y >= x; y--){
        document.write("*");
    }
    document.write("<br>");
}
*/

//punto 10

var clientes =prompt("¿vas a compar?");
var numeroPro =parseInt(prompt("Dijite el numero de productos"));
var x=1;
var totalDia=0;
var totalClientes=0;
while(clientes !="no"){
    document.write("cliente#"+x+"<br>");
    document.write("# productos"+numeroPro+"<br>");
    var y=1;
    var totalPagar=0;
    while(y <= numeroPro){
        var nombrePro=prompt("dijite nombre del producto"+y);
        var precioPro=parseInt(prompt("Dijite precio del producto"+y));
        document.write("producto"+nombrePro+":"+precioPro+"<br>");
        totalPagar=totalPagar+precioPro;
        y++;

    }
    totalDia=totalDia+totalPagar;
    document.write("Total a pagaar es:"+totalPagar+"<br>");
    clientes=prompt("¿desea seguir comparndo");
    x++;
    totalClientes++;
}
document.write("mumero de clientes del dia:"+totalClientes+"<br>");
document.write("total compras del dia:"+totalDia+"<br>");


var clientes =prompt("¿vas a compar?");
var numeroPro =parseInt(prompt("Dijite el numero de productos"));
var totalDia=0;
var totalClientes=0;
for(var x=1; clientes !="no";x++){
    document.write("cliente#"+x+"<br>");
    document.write("# productos"+numeroPro+"<br>");
   
    var totalPagar=0;
    for( var y=1;y <= numeroPro ; y++){
        var nombrePro=prompt("dijite nombre del producto"+y);
        var precioPro=parseInt(prompt("Dijite precio del producto"+y));
        document.write("producto"+nombrePro+":"+precioPro+"<br>");
        totalPagar=totalPagar+precioPro;
      

    }
    totalDia=totalDia+totalPagar;
    document.write("Total a pagaar es:"+totalPagar+"<br>");
    clientes=prompt("¿desea seguir comparndo");
  
    totalClientes++;
}
document.write("mumero de clientes del dia:"+totalClientes+"<br>");
document.write("total compras del dia:"+totalDia+"<br>");



 